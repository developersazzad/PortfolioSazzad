# Rollback M001

1. Take the site out of an active mixed-version deployment before reverting.
2. Restore the **actual target pre-install backups** of the eight modified files: `index.php`, `head.php`, `footer.php`, `assets/js/main.js`, `assets/js/main.v7.js`, `res/faq.html`, `res/privacy.html`, `sitemap.xml`.
3. Revert header script loading, footer form handling and both legacy menu guards together. Partial rollback can produce duplicate or absent menu handlers.
4. Remove only ADD files from this module's manifest that were absent before installation and have not acquired subsequent edits. If later posts/modules depend on them, resolve those dependencies instead of deleting the whole blog folder.
5. If you merged rather than replaced a modified file, reverse the exact module diff or restore your own backup—not an arbitrary upstream full-project copy.
6. Clear the same page/CDN caches used for deployment, then test homepage menu, project grid and contact form.
7. No database rollback or credential change is necessary. Never delete `.git/`, the repository root, unrelated assets or existing case studies.

The ZIP contains no destructive rollback automation. Keep the external backup until staging and production verification are complete.
