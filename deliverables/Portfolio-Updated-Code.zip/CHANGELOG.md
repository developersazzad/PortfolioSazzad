# M001 — 1.0.0

- Added blog listing and a complete educational demo article.
- Integrated existing FAQ/Privacy URLs with matching main navigation/footer.
- Added Blog/FAQs/Privacy to homepage desktop/mobile navigation and fixed footer placeholders.
- Added shared immediate navigation ownership; both legacy main JS copies yield the menu to the shared controller.
- Shared newsletter handling uses existing PHP endpoint; no new backend/storage.
- Added fluid editorial styles, local illustration/social art and progressive reading/search controls.
- Preserved 32 FAQ answers and revised Privacy's outdated technical claims.
- Added schemas, metadata, RSS and four sitemap entries.
- Added developer-controlled content sources, deterministic Python builder and browser tests.
- No PHPMailer, contact endpoint, existing case studies, main stylesheet, fonts, CV, credentials or hosting configuration changed.

The exact ADD/MODIFY list and payload hashes are in manifest.json. No deletions are declared.
