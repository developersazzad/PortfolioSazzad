# M001 test results

## Completed

- Build consistency: `python3 tools/build_public_pages.py --check` passed.
- JavaScript syntax: new shared shell/journal scripts and both modified homepage bundles passed `node --check`.
- PHP homepage syntax checked using PHP-WASM CLI; homepage HTML was rendered using that runtime. A native production PHP installation was not available.
- **48 responsive checks:** Blog, demo article, FAQ and Privacy at 320, 360, 440, 560, 678, 912, 1200, 1300, 1400, 1500, 1600 and 1920px. No document/body horizontal overflow at these checkpoints.
- **8 axe scans:** four pages at 440 and 1400px, WCAG 2 A/AA, WCAG 2.1 AA and best-practice rules. Final scan found **zero violations**. This is an automated result, not complete WCAG certification.
- One h1/main per new page, canonical presence and JSON-LD JSON parsing checked.
- Blog search/topic filtering, empty/clear state and query reload checked.
- 32 FAQ native disclosures, search and clear checked.
- Menu focus trap, Escape, focus/background restoration and desktop-resize close checked. A first-frame CSS visibility/focus issue was found and corrected.
- Article text-size/persistence, copy controls and reading progress checked. Browser-local storage unavailable state checked.
- All four pages readable with JavaScript disabled; FAQ disclosure still works.
- Newsletter mocked success/error states checked; no actual email sent.
- Homepage menu checked both immediately and after legacy bundle loading; 15 project cards and View All behavior checked.
- New-page desktop/mobile screenshots were inspected during development.

## Important remaining checks / limitations

The broader browser regression run was **not a completely clean pass**: it reported one `Failed to execute 'appendChild' on 'Node': Illegal return statement` browser event. The originating script was not isolated before this requested ZIP handoff. The feature assertions above completed, and the modified JS files parse successfully, but this browser error must be investigated on the target staging console rather than silently described as resolved. The test source is included so it can be reproduced.

The baseline homepage also contains four already-documented renderers targeting absent containers (bring/principles/available/marquee). This module intentionally does not redesign those unrelated homepage sections.

Not performed: production Lighthouse/PageSpeed measurement, field Core Web Vitals measurement, real mail delivery, live search indexing/rich-result testing, cross-browser Safari/Firefox testing, manual screen-reader certification or legal policy review.

The temporary preview served the generated static pages and PHP-rendered homepage HTML; it is not evidence of Apache/LiteSpeed/CDN behavior. Existing contact-endpoint anti-abuse concerns and cache settings remain outside this module.

## Release checks

ZIP integrity, safe relative paths, manifest payload SHA-256 checks, original-file baseline hashes and generated-output consistency are validated during packaging. Production installation is intentionally a user-reviewed operation, not an automatic deployment.
