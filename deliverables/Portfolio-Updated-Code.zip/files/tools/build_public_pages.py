#!/usr/bin/env python3
"""Build the static Blog/FAQ/Privacy pages from trusted, version-controlled content.
Python 3.9+ standard library only. Run from any directory. --check never writes.
The homepage header/footer are the shared source; rerun after changing either.
"""
import argparse
import html
import json
import re
from datetime import date
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
SITE = json.loads((ROOT / 'content/site.json').read_text(encoding='utf-8'))
BASE = SITE['url'].rstrip('/')
POSTS = json.loads((ROOT / 'content/blog/posts.json').read_text(encoding='utf-8'))
FAQ = json.loads((ROOT / 'content/faq.json').read_text(encoding='utf-8'))
OUTPUT = {}
esc = lambda value: html.escape(str(value), quote=True)
def text(value):
    return re.sub(r'\s+', ' ', html.unescape(re.sub(r'<[^>]+>', ' ', value))).strip()
def full(path): return BASE + '/' + path.lstrip('/')
def human_date(value): return date.fromisoformat(value).strftime('%d %B %Y').lstrip('0')
def write(path, data): OUTPUT[path] = data.rstrip() + '\n'
def data_json(data): return json.dumps(data, ensure_ascii=False, separators=(',', ':')).replace('<', '\\u003c')
def icon_search(): return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" aria-hidden="true"><circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 5 5"/></svg>'
def breadcrumbs(items):
    return '<nav class="journal-crumbs" aria-label="Breadcrumb">' + '<span aria-hidden="true">/</span>'.join(f'<a href="{esc(url)}">{esc(label)}</a>' if url else f'<span aria-current="page">{esc(label)}</span>' for label,url in items) + '</nav>'
def shell(prefix, active):
    home = (ROOT / 'index.php').read_text(encoding='utf-8')
    match = re.search(r'(<header id="site-header".*?)(?=\s*<main id="main")', home, re.S)
    if not match: raise ValueError('Homepage header markers changed. Update shell extraction first.')
    header = match[1].strip()
    footer_src = (ROOT / 'footer.php').read_text(encoding='utf-8')
    footer = re.search(r'<footer class="footer-v2">.*?</footer>', footer_src, re.S).group(0)
    def rewrite(m):
        value = m[1]
        if value.startswith(('http:', 'https:', 'mailto:', 'data:', 'tel:')): return m[0]
        return 'href="' + prefix + value + '"'
    header = re.sub(r'href="([^"]*)"', rewrite, header)
    footer = re.sub(r'href="([^"]*)"', rewrite, footer)
    footer = footer.replace('action="process_contact.php"', f'action="{prefix}process_contact.php"')
    for target in [prefix + active]:
        header = header.replace(f'href="{target}" class="nav-link"', f'href="{target}" class="nav-link" aria-current="page"')
        header = header.replace(f'href="{target}" class="mobile-link"', f'href="{target}" class="mobile-link" aria-current="page"')
    # Static footer is intentionally the same homepage footer, without homepage-only FAB/JS.
    return header, footer

def common_graph(path, name, description, kind, crumbs):
    url = full(path)
    return [
      {'@type':'Person','@id':full('#person'),'name':SITE['name'],'url':full(''),'jobTitle':'Full-Stack Web Developer','image':full('assets/img/sazzad.webp'),'sameAs':['https://github.com/developersazzad','https://www.linkedin.com/in/developer-sazzad/']},
      {'@type':'WebSite','@id':full('#website'),'url':full(''),'name':'Sazzad Hossain | Portfolio','publisher':{'@id':full('#person')},'inLanguage':'en'},
      {'@type':kind,'@id':url+'#webpage','url':url,'name':name,'description':description,'isPartOf':{'@id':full('#website')},'inLanguage':'en','breadcrumb':{'@id':url+'#breadcrumb'}},
      {'@type':'BreadcrumbList','@id':url+'#breadcrumb','itemListElement':[{'@type':'ListItem','position':n,'name':label,'item':full(target)} for n,(label,target) in enumerate(crumbs,1)]}
    ]

def page(path, prefix, title, description, body, active, graph, article=None):
    header, footer = shell(prefix, active)
    image = full('assets/blog/performance-social.png') if active == 'blog/' else full('assets/img/og-image.webp')
    extras = ''
    if article:
        extras = f'<meta property="article:published_time" content="{article["published"]}T00:00:00+06:00"><meta property="article:modified_time" content="{article["modified"]}T00:00:00+06:00"><meta property="article:author" content="{full("")}">'
    document = f'''<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{esc(title)}</title><meta name="description" content="{esc(description)}">
<meta name="robots" content="index,follow,max-image-preview:large"><link rel="canonical" href="{esc(full(path))}">
<meta name="theme-color" content="#0a0a0f"><meta name="author" content="Sazzad Hossain">
<meta property="og:type" content="{'article' if article else 'website'}"><meta property="og:title" content="{esc(title)}"><meta property="og:description" content="{esc(description)}"><meta property="og:url" content="{esc(full(path))}"><meta property="og:site_name" content="Sazzad Hossain"><meta property="og:locale" content="en_US"><meta property="og:image" content="{image}"><meta property="og:image:alt" content="{'Performance-first websites — engineering notes by Sazzad Hossain' if active=='blog/' else 'Sazzad Hossain — Full-Stack Web Developer'}">
<meta name="twitter:card" content="summary_large_image"><meta name="twitter:title" content="{esc(title)}"><meta name="twitter:description" content="{esc(description)}"><meta name="twitter:image" content="{image}">{extras}
<link rel="icon" href="{prefix}assets/img/favicon.png" type="image/png"><link rel="alternate" type="application/rss+xml" title="Sazzad's Engineering Notes" href="{prefix}blog/feed.xml">
<link rel="preload" href="{prefix}assets/fonts/Inter-Variable.woff2" as="font" type="font/woff2" crossorigin><link rel="preload" href="{prefix}assets/fonts/SpaceGrotesk-Regular.woff2" as="font" type="font/woff2" crossorigin>
<link rel="stylesheet" href="{prefix}assets/css/main.css?v=20261012a11y_v2"><link rel="stylesheet" href="{prefix}assets/css/site-shell.css?v=M001-1"><link rel="stylesheet" href="{prefix}assets/css/journal.css?v=M001-1">
<script src="{prefix}assets/js/site-shell.js?v=M001-1" defer></script><script src="{prefix}assets/js/journal.js?v=M001-1" defer></script>
<script type="application/ld+json">{data_json({'@context':'https://schema.org','@graph':graph})}</script>
</head>
<body class="editorial-page"><a class="site-skip-link" href="#main">Skip to content</a>
{header}
<noscript><nav class="site-noscript-nav" aria-label="Additional pages"><a href="{prefix}">Home</a><a href="{prefix}blog/">Blog</a><a href="{prefix}res/faq.html">FAQs</a><a href="{prefix}res/privacy.html">Privacy</a></nav></noscript>
{body}
{footer}
</body></html>'''
    write(path+'index.html' if path.endswith('/') else path, document)

# Validate slugs and trusted source paths; never accept public request input as a filename.
slugs = set()
for post in POSTS:
    if not re.fullmatch(r'[a-z0-9]+(?:-[a-z0-9]+)*', post['slug']) or post['slug'] in slugs: raise ValueError('Invalid or duplicate blog slug')
    slugs.add(post['slug'])
    content_path = (ROOT/'content/blog'/post['content']).resolve()
    if content_path.parent != (ROOT/'content/blog').resolve(): raise ValueError('Content file must be inside content/blog')
    post['_body'] = content_path.read_text(encoding='utf-8')
    post['_words'] = len(re.findall(r"\b[\w’'-]+\b", text(post['_body'])))
    post['_minutes'] = max(1, round(post['_words']/220))
    post['_path'] = f'blog/{post["slug"]}/'
    date.fromisoformat(post['published']); date.fromisoformat(post['modified'])
    if post['modified'] < post['published']: raise ValueError('modified cannot precede published')
POSTS.sort(key=lambda p:p['published'],reverse=True)

def author(prefix, post):
    return f'<div class="journal-byline"><img src="{prefix}assets/img/sazzad.webp" alt="" width="32" height="32" loading="lazy"><div><b>Sazzad Hossain</b><small>{human_date(post["published"])} <span aria-hidden="true">·</span> {post["_minutes"]} min read</small></div></div>'

# BLOG INDEX: all cards are in the generated HTML. JS filters, never fetches the content.
cards=[]
for n,p in enumerate(POSTS):
    tags='|'.join(sorted(set([p['category']]+p['tags'])))
    search=' '.join([p['title'],p['subtitle'],p['excerpt'],tags]).lower()
    cards.append(f'''<article class="journal-card" data-article data-topics="{esc(tags)}" data-search="{esc(search)}">
<div class="journal-card-copy"><div class="journal-card-eyebrow"><span class="journal-tag">↗ {esc(p['category'])}</span><span>{'DEMO ARTICLE' if p.get('demo') else 'ENGINEERING NOTE'} / {n+1:03}</span></div>
<h3><a href="{p['slug']}/">{esc(p['title'])}</a></h3><p>{esc(p['excerpt'])}</p>{author('../',p)}<a class="journal-read-link" href="{p['slug']}/">Read the article <span aria-hidden="true">↗</span><span class="sr-only">: {esc(p['title'])}</span></a></div>
<div class="journal-art"><img src="../{p['image']}" alt="{esc(p['image_alt'])}" width="1200" height="840" {'fetchpriority="high"' if n==0 else 'loading="lazy"'} decoding="async"></div></article>''')
topics=list(dict.fromkeys(p['category'] for p in POSTS))
if any('Accessibility' in p['tags'] for p in POSTS) and 'Accessibility' not in topics:topics.append('Accessibility')
filters='<button class="journal-filter" type="button" data-topic="all" aria-pressed="true">All articles</button>'+''.join(f'<button class="journal-filter" type="button" data-topic="{esc(t)}" aria-pressed="false">{esc(t)}</button>' for t in topics)
body=f'''<main id="main" tabindex="-1"><div class="journal-wrap">
{breadcrumbs([('Home','../'),('The blog',None)])}
<header class="journal-hero"><div><p class="journal-kicker">The developer's notebook / Vol. 01</p><h1>Build better.<br><span>Share the how.</span></h1></div><div class="journal-intro"><p>Notes on the decisions behind the code.<br>Practical ideas for faster websites, thoughtful interfaces, and software that works in the real world.</p><div class="journal-mini-meta"><span><i aria-hidden="true"></i> ENGINEERING, EXPLAINED</span><span>BY SAZZAD HOSSAIN ↗</span></div></div></header>
<section class="journal-library" aria-labelledby="latest-title"><div class="journal-toolbar" data-blog-tools hidden><div class="journal-filters" role="group" aria-label="Filter articles by topic">{filters}</div><div class="journal-search"><label class="sr-only" for="blog-search">Search articles</label>{icon_search()}<input id="blog-search" type="search" maxlength="200" placeholder="Find something useful…" autocomplete="off"></div></div>
<div class="journal-section-label"><h2 id="latest-title">Latest from the notebook</h2><span id="blog-count" class="journal-result-count" role="status" aria-live="polite">{len(POSTS)} {'article' if len(POSTS)==1 else 'articles'}</span></div>
<div data-blog-list>{''.join(cards)}</div><div id="blog-empty" class="journal-empty" hidden><h3>No matching notes. Yet.</h3><p>Try another search or explore all articles.</p><button class="journal-filter" type="button" data-clear-blog>Clear search &amp; filters</button></div>
<div class="journal-lower"><aside class="journal-note"><span class="journal-note-icon" aria-hidden="true">&lt;/&gt;</span><div><h2>Less noise. More useful.</h2><p>Clear explanations, small examples, and honest trade-offs. Written to help you make the next decision—not to add another buzzword.</p></div></aside><aside class="journal-note"><span class="journal-note-icon" aria-hidden="true">↗</span><div><h2>See the work behind the words.</h2><p>Explore the projects that put these ideas into practice. <a href="../#work">View selected work</a> or <a href="feed.xml">follow the RSS feed</a>.</p></div></aside></div><p class="journal-endnote">THOUGHTFULLY BUILT. OPENLY SHARED.</p>
</section></div></main>'''
graph=common_graph('blog/',"Engineering Blog | Sazzad Hossain","Practical notes on web performance, accessible interfaces, PHP and building useful software.",'CollectionPage',[('Home',''),('Blog','blog/')])
graph[2]['mainEntity']={'@id':full('blog/#blog')}
graph.append({'@type':'Blog','@id':full('blog/#blog'),'url':full('blog/'),'name':"Sazzad's Engineering Notes",'description':graph[2]['description'],'inLanguage':'en','author':{'@id':full('#person')},'blogPost':[{'@type':'BlogPosting','headline':p['title'],'url':full(p['_path']),'datePublished':p['published']+'T00:00:00+06:00','author':{'@id':full('#person')}} for p in POSTS]})
page('blog/','../','Engineering Blog | Sazzad Hossain',graph[2]['description'],body,'blog/',graph)

# ARTICLE PAGES
for p in POSTS:
    headings=re.findall(r'<section id="([^"]+)">\s*<h2>(.*?)</h2>',p['_body'],re.S)
    toc=''.join(f'<li><a href="#{id}">{esc(text(label))}</a></li>' for id,label in headings)
    body=f'''<div class="entry-progress" aria-hidden="true"><span></span></div><main id="main" tabindex="-1"><div class="journal-wrap">{breadcrumbs([('Home','../../'),('Blog','../'),('Engineering note',None)])}
<article aria-labelledby="article-title"><header class="entry-header"><div class="journal-card-eyebrow"><span class="journal-tag">↗ {esc(p['category'])}</span><span>{'DEMO ARTICLE' if p.get('demo') else 'ENGINEERING NOTE'}</span><span>{p['_minutes']} MIN READ</span></div><h1 id="article-title">{esc(p['title'])}</h1><p class="entry-subtitle">{esc(p['subtitle'])}</p>{author('../../',p)}<div class="entry-dates"><span>Published <time datetime="{p['published']}">{human_date(p['published'])}</time></span><span>Updated <time datetime="{p['modified']}">{human_date(p['modified'])}</time></span></div></header>
<figure class="entry-cover"><img src="../../{p['image']}" alt="{esc(p['image_alt'])}" width="1200" height="840" fetchpriority="high"><figcaption>Start with useful HTML. Add only what makes the experience better.</figcaption></figure>
<div class="entry-layout"><div class="entry-body" data-reading-body><div class="entry-takeaway"><h2>The short answer</h2><p>{esc(p['takeaway'])}</p></div>{p['_body']}
<footer class="entry-author"><img src="../../assets/img/sazzad.webp" alt="Sazzad Hossain" width="64" height="64" loading="lazy"><div><h2>Written by Sazzad Hossain</h2><p>Full-stack web developer based in Chittagong, Bangladesh. Building practical websites and business systems. <a href="../../#about">More about Sazzad ↗</a></p></div></footer><a class="entry-back" href="../">← Back to all articles</a></div>
<aside class="entry-sidebar" aria-label="Reading tools"><details class="entry-contents" open><summary>On this page</summary><nav aria-label="Article contents"><ol>{toc}</ol></nav></details><div class="entry-tools" data-reading-tools hidden><button type="button" data-text-size="decrease" aria-label="Decrease article text size">A−</button><button type="button" data-text-size="increase" aria-label="Increase article text size">A+</button><button type="button" data-copy-link>Copy link ↗</button></div><p class="entry-status" id="reader-status" role="status" aria-live="polite"></p><p class="entry-sidebar-note">Read at your pace. Text-size preferences stay in your browser.</p>{'<p class="entry-demo"><strong>About this demo</strong><br>A complete example article for this new journal. The guidance is educational; no website scores or project outcomes are claimed.</p>' if p.get('demo') else ''}</aside></div></article></div></main>'''
    graph=common_graph(p['_path'],p['seo_title'],p['description'],'WebPage',[('Home',''),('Blog','blog/'),(p['title'],p['_path'])])
    graph[2]['mainEntity']={'@id':full(p['_path']+'#article')}
    graph.append({'@type':'BlogPosting','@id':full(p['_path']+'#article'),'mainEntityOfPage':{'@id':full(p['_path']+'#webpage')},'headline':p['title'],'alternativeHeadline':p['subtitle'],'description':p['description'],'image':{'@type':'ImageObject','url':full('assets/blog/performance-social.png'),'width':1200,'height':630},'datePublished':p['published']+'T00:00:00+06:00','dateModified':p['modified']+'T00:00:00+06:00','author':{'@id':full('#person')},'publisher':{'@id':full('#person')},'inLanguage':'en','articleSection':p['category'],'keywords':p['tags'],'wordCount':p['_words'],'isAccessibleForFree':True,'isPartOf':{'@type':'Blog','@id':full('blog/#blog')},'citation':re.findall(r'<a href="(https://[^"]+)"',p['_body'])})
    page(p['_path'],'../../',p['seo_title']+' | Sazzad Hossain',p['description'],body,'blog/',graph,p)

# FAQ: preserve original 32 answers, with native accessible disclosures.
faq_nav=''.join(f'<a href="#{g["id"]}">{esc(g["title"])}</a>' for g in FAQ)
faq_sections=[];questions=[]
for g in FAQ:
    details=[]
    for n,item in enumerate(g['items']):
        details.append(f'<details class="faq-item"{ " open" if len(questions)==0 else ""}><summary>{esc(item["question"])}</summary><div class="faq-answer">{item["answer"]}</div></details>')
        questions.append({'@type':'Question','name':item['question'],'acceptedAnswer':{'@type':'Answer','text':text(item['answer'])}})
    faq_sections.append(f'<section class="faq-group" id="{g["id"]}"><h2>{esc(g["title"])}</h2>{"".join(details)}</section>')
body=f'''<main id="main" tabindex="-1"><div class="journal-wrap">{breadcrumbs([('Home','../'),('FAQs',None)])}<header class="resource-header"><p class="journal-kicker">Good projects start with clear answers</p><h1>Questions?<br><span>Let's clear things up.</span></h1><p>What I build, how we work together, and what happens after launch. Straightforward answers before we write the first line of code.</p><div class="resource-meta"><span>32 questions</span><span>Worldwide · remote</span><span>English / বাংলা</span></div></header>
<div class="resource-content faq-layout"><aside class="faq-navigation" aria-label="Question categories"><h2>Find your answer</h2><nav aria-label="Question categories">{faq_nav}</nav></aside><div><div data-faq-tools hidden><div class="journal-search faq-search"><label class="sr-only" for="faq-search">Search questions and answers</label>{icon_search()}<input type="search" id="faq-search" placeholder="Search questions…" maxlength="200"></div><p id="faq-count" class="journal-result-count" role="status" aria-live="polite">32 questions</p></div>{''.join(faq_sections)}<div class="journal-empty" id="faq-empty" hidden><h2>No matching questions</h2><p>Try another word, or contact me directly.</p><button type="button" class="journal-filter" data-clear-faq>Clear search</button></div><aside class="resource-cta" aria-label="Contact Sazzad"><h2>Still have a question?</h2><p>No ticket queues. Tell me what you are thinking about, and let's find the right next step.</p><a href="../#contact">Let's talk about your project ↗</a></aside></div></div></div></main>'''
graph=common_graph('res/faq.html','Frequently Asked Questions | Sazzad Hossain','Answers about web development services, project timelines, pricing, handover and support.','FAQPage',[('Home',''),('FAQs','res/faq.html')]);graph[2]['mainEntity']=questions
page('res/faq.html','../',graph[2]['name'],graph[2]['description'],body,'res/faq.html',graph)

# PRIVACY: content is maintained separately from visual shell.
privacy=(ROOT/'content/privacy.html').read_text(encoding='utf-8')
headings=re.findall(r'<section id="([^"]+)">\s*<h2>(.*?)</h2>',privacy,re.S)
toc=''.join(f'<li><a href="#{id}">{esc(text(label))}</a></li>' for id,label in headings)
body=f'''<main id="main" tabindex="-1"><div class="journal-wrap">{breadcrumbs([('Home','../'),('Privacy',None)])}<header class="resource-header"><p class="journal-kicker">Your information. Treated with care.</p><h1>A little clarity.<br><span>A lot of respect.</span></h1><p>Privacy Policy — what happens to your information when you read this site, contact me, or ask for updates. Written to be read, not hidden away.</p><div class="resource-meta"><span>Updated {human_date(SITE['resource_updated'])}</span><span>{esc(BASE.split('://')[-1])}</span></div></header><div class="resource-content privacy-layout"><div class="entry-body privacy-copy">{privacy}</div><aside class="entry-sidebar"><details class="entry-contents" open><summary>In this policy</summary><nav aria-label="Privacy policy contents"><ol>{toc}</ol></nav></details></aside></div></div></main>'''
graph=common_graph('res/privacy.html','Privacy Policy | Sazzad Hossain','How this portfolio handles contact information, update requests, browser preferences and third-party services.','WebPage',[('Home',''),('Privacy','res/privacy.html')]);graph[2]['dateModified']=SITE['resource_updated']
page('res/privacy.html','../',graph[2]['name'],graph[2]['description'],body,'res/privacy.html',graph)

# RSS and sitemap are deterministic; no fake updated timestamps on unchanged posts.
rss=ET.Element('rss',version='2.0');channel=ET.SubElement(rss,'channel')
for key,value in [('title',"Sazzad's Engineering Notes"),('link',full('blog/')),('description','Practical notes on performance, accessibility and building useful software.'),('language','en')]:ET.SubElement(channel,key).text=value
from email.utils import format_datetime
from datetime import datetime, timezone, timedelta
for p in POSTS:
    item=ET.SubElement(channel,'item')
    for key,value in [('title',p['title']),('link',full(p['_path'])),('description',p['excerpt']),('category',p['category']),('pubDate',format_datetime(datetime.fromisoformat(p['published']).replace(tzinfo=timezone(timedelta(hours=6)))) )]:ET.SubElement(item,key).text=value
    ET.SubElement(item,'guid',isPermaLink='true').text=full(p['_path'])
write('blog/feed.xml','<?xml version="1.0" encoding="UTF-8"?>\n'+ET.tostring(rss,encoding='unicode'))
ns='http://www.sitemaps.org/schemas/sitemap/0.9';ET.register_namespace('',ns)
sitemap=ET.fromstring((ROOT/'sitemap.xml').read_text(encoding='utf-8'))
new_urls={'blog/':max((p['modified'] for p in POSTS),default=SITE['resource_updated']),'res/faq.html':SITE['resource_updated'],'res/privacy.html':SITE['resource_updated']}
new_urls.update({p['_path']:p['modified'] for p in POSTS})
for path,modified in new_urls.items():
    element=next((el for el in sitemap if el.find('{'+ns+'}loc').text==full(path)),None)
    if element is None:element=ET.SubElement(sitemap,'{'+ns+'}url');ET.SubElement(element,'{'+ns+'}loc').text=full(path)
    lastmod=element.find('{'+ns+'}lastmod')
    if lastmod is None:lastmod=ET.SubElement(element,'{'+ns+'}lastmod')
    lastmod.text=modified
ET.indent(sitemap,space='  ')
write('sitemap.xml','<?xml version="1.0" encoding="UTF-8"?>\n'+ET.tostring(sitemap,encoding='unicode'))

if __name__=='__main__':
    args=argparse.ArgumentParser(description=__doc__);args.add_argument('--check',action='store_true');options=args.parse_args()
    differences=[]
    for path,value in OUTPUT.items():
        dest=ROOT/path
        if options.check:
            if not dest.exists() or dest.read_text(encoding='utf-8')!=value:differences.append(path)
        else:dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(value,encoding='utf-8');print('Built',path)
    if differences:raise SystemExit('Generated pages are stale: '+', '.join(differences))
    if options.check:print('All generated pages, RSS and sitemap are up to date.')
