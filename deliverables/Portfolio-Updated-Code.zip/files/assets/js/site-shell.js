/* Shared immediately-deferred shell. Legacy homepage bundle yields navigation ownership. */
(() => {
  'use strict';
  window.portfolioShellOwnsNavigation = true;
  const button = document.getElementById('menu-btn');
  const panel = document.getElementById('mobile-panel');
  const header = document.getElementById('site-header');
  let previousFocus, previousOverflow = '', background = [];
  const isOpen = () => panel?.getAttribute('aria-hidden') === 'false';
  function closeMenu(restore = true) {
    if (!panel || !isOpen()) return;
    panel.classList.remove('is-active'); panel.setAttribute('aria-hidden', 'true'); panel.inert = true;
    button.setAttribute('aria-expanded', 'false'); document.body.style.overflow = previousOverflow;
    background.forEach(([node, inert]) => { node.inert = inert; }); background = [];
    if (restore) previousFocus?.focus();
  }
  if (button && panel) {
    button.addEventListener('click', () => {
      if (isOpen()) return closeMenu();
      previousFocus = document.activeElement; previousOverflow = document.body.style.overflow;
      background = [...document.body.children].filter(node => node !== panel && !['SCRIPT','STYLE','LINK'].includes(node.tagName)).map(node => [node, node.inert]);
      background.forEach(([node]) => { node.inert = true; });
      panel.inert = false; panel.classList.add('is-active'); panel.setAttribute('aria-hidden', 'false');
      button.setAttribute('aria-expanded', 'true'); document.body.style.overflow = 'hidden';
      panel.querySelector('.mobile-close-btn')?.focus();
    });
    panel.querySelector('.mobile-close-btn')?.addEventListener('click', () => closeMenu());
    panel.addEventListener('click', event => { if (event.target.closest('a')) closeMenu(); });
    document.addEventListener('keydown', event => {
      if (!isOpen()) return;
      if (event.key === 'Escape') { event.preventDefault(); closeMenu(); }
      if (event.key === 'Tab') {
        const elements = [...panel.querySelectorAll('a[href],button:not([disabled])')].filter(node => node.getClientRects().length);
        const first = elements[0], last = elements[elements.length - 1];
        if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
        else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
      }
    });
    window.matchMedia('(min-width:1200px)').addEventListener('change', event => { if (event.matches) closeMenu(false); });
  }
  if (header && document.body.classList.contains('editorial-page')) {
    header.style.background = 'rgba(10,10,15,.97)'; header.style.borderBottom = '1px solid var(--border)';
  }
  document.querySelectorAll('[data-newsletter]').forEach(form => {
    form.addEventListener('submit', async event => {
      event.preventDefault(); if (!form.reportValidity()) return;
      const submit = form.querySelector('[type=submit]'), status = document.getElementById('subscribe-status');
      if (submit.disabled) return;
      submit.disabled = true; status.textContent = 'Sending your request…';
      const controller = new AbortController(), timeout = setTimeout(() => controller.abort(), 15000);
      try {
        const response = await fetch(form.action, {method:'POST', body:new FormData(form), signal:controller.signal, headers:{Accept:'application/json'}});
        const data = await response.json();
        if (!response.ok || data.status !== 'success') throw new Error('delivery');
        status.textContent = 'Request sent. Thank you for your interest in updates!'; form.reset();
      } catch (_) { status.textContent = 'Your request could not be confirmed. Please email developer.sazzad.me@gmail.com, or try again later.'; }
      finally { clearTimeout(timeout); submit.disabled = false; }
    });
  });
})();
