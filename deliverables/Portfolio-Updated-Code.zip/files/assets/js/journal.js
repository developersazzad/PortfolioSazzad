/* Static content first. All controls below are progressive enhancements. */
(() => {
  'use strict';
  const listing = document.querySelector('[data-blog-list]');
  if (listing) {
    const search = document.getElementById('blog-search'), filters = [...document.querySelectorAll('[data-topic]')];
    const cards = [...listing.querySelectorAll('[data-article]')], count = document.getElementById('blog-count'), empty = document.getElementById('blog-empty');
    const topics = filters.map(button => button.dataset.topic);
    const url = new URL(location.href);
    let topic = topics.includes(url.searchParams.get('topic')) ? url.searchParams.get('topic') : 'all';
    search.value = (url.searchParams.get('q') || '').slice(0, 200);
    document.querySelector('[data-blog-tools]').hidden = false;
    let timer;
    function apply(updateUrl = true) {
      const term = search.value.trim().toLocaleLowerCase(); let visible = 0;
      cards.forEach(card => {
        const matches = (topic === 'all' || card.dataset.topics.split('|').includes(topic)) && card.dataset.search.includes(term);
        card.hidden = !matches; if (matches) visible++;
      });
      filters.forEach(button => button.setAttribute('aria-pressed', String(button.dataset.topic === topic)));
      count.textContent = `${visible} ${visible === 1 ? 'article' : 'articles'}`; empty.hidden = visible !== 0;
      if (updateUrl) {
        const next = new URL(location.href);
        term ? next.searchParams.set('q', search.value.trim()) : next.searchParams.delete('q');
        topic === 'all' ? next.searchParams.delete('topic') : next.searchParams.set('topic', topic);
        history.replaceState(null, '', next);
      }
    }
    filters.forEach(button => button.addEventListener('click', () => { topic = button.dataset.topic; apply(); }));
    search.addEventListener('input', () => { clearTimeout(timer); timer = setTimeout(apply, 120); });
    document.querySelector('[data-clear-blog]')?.addEventListener('click', () => { search.value = ''; topic = 'all'; apply(); search.focus(); });
    apply(false);
  }
  const faqSearch = document.getElementById('faq-search');
  if (faqSearch) {
    document.querySelector('[data-faq-tools]').hidden = false;
    const groups = [...document.querySelectorAll('.faq-group')], items = [...document.querySelectorAll('.faq-item')];
    faqSearch.value = (new URL(location.href).searchParams.get('q') || '').slice(0,200);
    function filterFaq() {
      const term = faqSearch.value.toLocaleLowerCase().trim(); let shown = 0;
      items.forEach(item => { item.hidden = !item.textContent.toLocaleLowerCase().includes(term); if (!item.hidden) shown++; });
      groups.forEach(group => { group.hidden = !group.querySelector('.faq-item:not([hidden])'); });
      document.getElementById('faq-count').textContent = `${shown} of ${items.length} questions`;
      document.getElementById('faq-empty').hidden = shown !== 0;
    }
    faqSearch.addEventListener('input', filterFaq);
    document.querySelector('[data-clear-faq]')?.addEventListener('click', () => {faqSearch.value='';filterFaq();faqSearch.focus();});
    document.querySelectorAll('.faq-navigation a').forEach(link => link.addEventListener('click', () => {faqSearch.value='';filterFaq();}));
    filterFaq();
  }
  const body = document.querySelector('[data-reading-body]');
  if (!body) return;
  const status = document.getElementById('reader-status'), sizeButtons = [...document.querySelectorAll('[data-text-size]')];
  document.querySelector('[data-reading-tools]').hidden = false;
  const sizes = [1,1.1,1.2]; let size = 0;
  try { const saved = Number(localStorage.getItem('portfolio-reading-size')); if ([0,1,2].includes(saved)) size = saved; } catch (_) {}
  function setSize(announce = true) {
    body.style.setProperty('--reading-scale', sizes[size]);
    sizeButtons.forEach(button => {button.disabled = (button.dataset.textSize === 'decrease' && size === 0) || (button.dataset.textSize === 'increase' && size === 2);});
    if (announce) {status.textContent=`Article text size: ${Math.round(sizes[size]*100)}%.`; try {localStorage.setItem('portfolio-reading-size',String(size));} catch (_) {}}
  }
  sizeButtons.forEach(button => button.addEventListener('click', () => {size=Math.max(0,Math.min(2,size+(button.dataset.textSize==='increase'?1:-1)));setSize();}));setSize(false);
  async function copyText(text, button, success) {
    try {
      if (navigator.clipboard && window.isSecureContext) await navigator.clipboard.writeText(text);
      else {
        const input=document.createElement('textarea');input.value=text;input.style.cssText='position:fixed;left:-9999px;top:0';document.body.append(input);input.select();
        const ok=document.execCommand('copy');input.remove();button.focus();if(!ok)throw new Error('copy');
      }
      status.textContent=success;
    } catch (_) {status.textContent='Automatic copy is unavailable. Select and copy the text or the address bar manually.';}
  }
  document.querySelector('[data-copy-link]')?.addEventListener('click',event => copyText(new URL(location.pathname,location.origin).href,event.currentTarget,'Article link copied.'));
  document.querySelectorAll('[data-copy-code]').forEach(button => {button.hidden=false;button.addEventListener('click',()=>copyText(button.closest('.entry-code').querySelector('code').textContent,button,'Code copied.'));});
  const contents = document.querySelector('.entry-contents');
  const narrow = window.matchMedia('(max-width:911px)');
  function adaptContents() { if(contents) contents.open = !narrow.matches; }
  adaptContents();narrow.addEventListener('change',adaptContents);
  const links = [...document.querySelectorAll('.entry-contents a')];
  if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver(entries => {
      const visible = entries.filter(entry => entry.isIntersecting).sort((a,b) => a.boundingClientRect.top-b.boundingClientRect.top);
      if (!visible.length) return;
      links.forEach(link => {if(link.hash==='#'+visible[0].target.id)link.setAttribute('aria-current','location');else link.removeAttribute('aria-current');});
    },{rootMargin:'-100px 0px -55% 0px',threshold:0});
    body.querySelectorAll('section[id]').forEach(section=>observer.observe(section));
  }
  const progress = document.querySelector('.entry-progress span');let scheduled=false;
  function updateProgress(){scheduled=false;if(!progress)return;const bounds=body.getBoundingClientRect();const distance=bounds.height-window.innerHeight+100;const ratio=distance>0?Math.min(1,Math.max(0,(100-bounds.top)/distance)):1;progress.style.transform=`scaleX(${ratio})`;}
  function schedule(){if(!scheduled){scheduled=true;requestAnimationFrame(updateProgress);}}
  window.addEventListener('scroll',schedule,{passive:true});window.addEventListener('resize',schedule);sizeButtons.forEach(button=>button.addEventListener('click',schedule));updateProgress();
})();
