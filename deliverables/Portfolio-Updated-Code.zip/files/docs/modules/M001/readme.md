# M001 — Blog, FAQ & Privacy integration

**Version:** 1.0.0 · **Date:** 2026-10-14 · **Project:** developersazzad/PortfolioSazzad

বাংলা: এই ZIP-এ শুধু এই module-এর changed/new files আছে—পুরো project নয়। `files/` folder-এর ভিতরের files আপনার project root-এ একই path-এ apply করুন। আগে backup নিন এবং `manifest.json` অনুযায়ী conflict check করুন। Root-এর package readme দিয়ে website-এর existing root readme replace করবেন না।

## 1. What is included

- Homepage desktop/mobile menu: Blog, FAQs and Privacy links.
- Existing `res/faq.html`: redesigned in the portfolio theme, all 32 original questions/answers, native accessible disclosures, search and categories.
- Existing `res/privacy.html`: matching layout/menu/footer and a readable 15-section policy.
- `/blog/`: static, crawlable article listing, search, topic filters, empty/reset state and shareable filter URLs.
- `/blog/performance-first-php-websites/`: one complete demo article, references, table of contents, reading progress, adjustable text size, copy-link/code controls and print styles.
- Local original SVG cover and a 1200×630 PNG social preview.
- Canonical URLs, descriptions, OpenGraph/Twitter metadata, Person/WebSite/WebPage/BreadcrumbList/Blog/BlogPosting/FAQPage JSON-LD as applicable.
- RSS feed at `/blog/feed.xml`, plus the four new/updated page URLs in the existing sitemap.
- Small shared navigation/newsletter script, rather than loading homepage project/animation code on reading pages.
- Python standard-library build script, trusted content files and browser regression test source.

**No database, CMS/admin panel, comments system, automatic email newsletter, new framework or npm production build is introduced.** This is a fully rendered flat-file blog: publishing means editing content and rebuilding static pages. The demo is visibly identified as a demo; owner review is needed before treating it as final editorial content.

## 2. URLs after installation

| Page | URL |
|---|---|
| Home | `/` |
| Blog | `/blog/` |
| Demo article | `/blog/performance-first-php-websites/` |
| FAQs | `/res/faq.html` |
| Privacy | `/res/privacy.html` |
| RSS | `/blog/feed.xml` |

The existing `res/` URLs are preserved; no Apache rewrite or redirect is required. Hosting must serve `index.html` for blog directories. PHP remains required for the existing homepage and contact endpoint. New reading pages themselves are static HTML.

## 3. Baseline and prerequisites

Built against commit `accb45bd9e7bc4cc1666361d0012cc4c23107bd0`. The research-only M000 package is **not required**. The original project must already contain shared `assets/css/main.css`, fonts, portraits/favicon, `process_contact.php` and PHPMailer. These unchanged dependencies are not unnecessarily duplicated in the ZIP.

The main site's existing `head.php`, `index.php`, `footer.php`, current `main.v7.js` and identical `main.js` are modified together. **Apply the entire module**, not just the Blog folder: the shared menu controller and the legacy-JS ownership guard must stay together.

## 4. Safe installation — Google Antigravity or another agent

1. Extract outside the public web root into a temporary staging directory.
2. Read this file, `TEST-RESULTS.md`, `ROLLBACK.md` and `manifest.json`.
3. Locate your actual project root containing `index.php`, `head.php`, `footer.php`, `assets/`, `case-study/` and `res/`.
4. Back up every existing file listed with `MODIFY` in the manifest. Store backups outside the web root. Record which `ADD` paths were previously absent.
5. Check target hashes against each `base_sha256`:
   - MODIFY with matching base: safe to replace with its payload.
   - Target already matches `sha256`: already installed; skip.
   - Different target content: **stop and merge carefully**, preserving your local changes.
   - ADD with a different existing file: conflict; do not overwrite blindly.
6. Copy the **contents of `files/`** into the project root, retaining every relative path. Do not upload a literal nested `files/` folder.
7. Package-level readme/manifest/checksums are installation metadata. Do not replace the site's root `readme.md` with them.
8. Deploy all changes as one release on staging. No SQL, Composer, server configuration or production npm command is required.
9. Visit every URL above, check the mobile menu and article controls, and confirm the real PHP contact endpoint works with your existing mail configuration. Use one controlled staging address, not bulk test messages.
10. Read the limitations below before production. Review Privacy text and the demo article with the owner.
11. Clear your existing CDN/page cache if necessary. New shell/journal assets use `?v=M001-1`. Existing global caching rules are deliberately untouched.

To verify package checksums after extraction on a system with sha256sum:

```sh
sha256sum -c CHECKSUMS.sha256
```

Hashes detect inconsistency; they are not a publisher signature. No install script runs or deletes anything automatically.

### Copy-paste Antigravity prompt

> Apply this M001 module to my existing PortfolioSazzad project. First read readme.md, manifest.json, TEST-RESULTS.md and ROLLBACK.md. Back up affected files outside the web root. Compare baseline hashes and preserve all local edits. Apply only manifest-declared files from files/, retaining project-relative paths. On a conflict, show a minimal merge rather than overwriting. Keep the shared shell and both legacy JS guards synchronized. Do not replace the site's root README, run SQL, install a framework, change hosting/mail configuration or deploy production automatically. Run the build consistency check and syntax/browser checks, review actual PHP email behavior on staging, and report exact changes and remaining issues. Review the Privacy copy and demo article before publishing. Return any merged files/diff so the next module uses my updated baseline.

## 5. Architecture / edit locations

| Purpose | Edit this source |
|---|---|
| Main navigation | Header/mobile menu in root `index.php` |
| Footer links/content | Root `footer.php` |
| Shared menu/form behavior | `assets/js/site-shell.js` |
| Shared menu/responsive fixes | `assets/css/site-shell.css` |
| Blog/resource design | `assets/css/journal.css` |
| Search, reading controls | `assets/js/journal.js` |
| Site domain / resource revision date | `content/site.json` |
| Blog metadata/index records | `content/blog/posts.json` |
| Demo article body | `content/blog/performance-first-php-websites.html` |
| FAQ questions/answers | `content/faq.json` |
| Privacy copy | `content/privacy.html` |
| Generation/layout/schema | `tools/build_public_pages.py` |

`res/*.html`, blog HTML and RSS are generated outputs. They are shipped ready to deploy. **Do not edit only a generated output**: regeneration would replace that edit. Change its source and rebuild.

The generator reuses the homepage's current header and footer markup at build time, adjusting relative URLs and active-page state. Static pages do not execute PHP includes or copy the homepage's delayed main JS. This keeps content readable without JavaScript and requires no runtime backend for the blog.

Whenever navigation/footer content changes, rebuild public pages. This build expects the existing header/main markers and a static `<footer class="footer-v2">`. If you later add PHP logic inside the extracted shell, adapt the generator first—do not accidentally publish PHP source into an HTML output.

## 6. Build / publish more articles

Python 3.9+ standard library only; no pip packages needed:

```sh
python3 tools/build_public_pages.py
python3 tools/build_public_pages.py --check
```

The check mode writes nothing and fails when outputs differ from their sources. The generator writes Blog listing/details, FAQ/Privacy, RSS and sitemap.

To add another article:

1. Create `content/blog/your-slug.html` containing trusted editorial HTML. Use sections in this form:
   ```html
   <section id="a-unique-heading">
     <h2>Your descriptive heading</h2>
     <p>Your useful explanation.</p>
   </section>
   ```
2. Copy an object in `content/blog/posts.json`. Give it a unique lowercase hyphenated `slug`, matching content filename, title, SEO title, subtitle, description, excerpt, category, tags, genuine publication/modification dates and takeaway.
3. Set `demo` to `false` only when the owner approves the real article. Do not fabricate outcomes or reviews.
4. Add an optimized cover asset and descriptive `image_alt`; set `image` to its project-relative path.
5. Reading time and word count are calculated at build time. TOC is generated from the section pattern above. Categories are generated from post records.
6. Rebuild and deploy newly generated pages, listing, feed, sitemap and any new assets together.
7. The current social preview/figure caption are tailored to the single demo. Before adding a differently themed article, update the generator's `page()` image metadata, BlogPosting image and article figure caption to support per-post values. Do not publish unrelated social images by accident.
8. Removing a post from JSON does **not** delete its existing generated directory or sitemap entry. Remove/archive them deliberately and configure an appropriate redirect or 404/410 policy on the real host. The generator intentionally performs no destructive cleanup.

Content files are developer/owner-controlled, trusted HTML. They are not a public submission API and are not HTML-sanitized. Never feed untrusted form content into them.

## 7. SEO / AEO / GEO approach

Implemented: useful server-delivered HTML, descriptive metadata, one h1, logical sections, visible authorship/dates, concise takeaway, references, canonical URLs, internal links, valid JSON-LD syntax, RSS and sitemap discovery.

The request's “AGO” is treated as answer-oriented content/discoverability (often called AEO), alongside GEO and conventional SEO. There is no secret ranking formula: structured data does not guarantee indexing, rich results, rankings or AI citations. FAQ rich results are restricted by search-provider eligibility and should not be promised for a personal portfolio. No fake reviews, hidden keywords or unsupported performance claims were added.

Default production domain: `https://sazzad.wedevspro.com`. For a different domain/subdirectory, update `content/site.json` and rebuild; also review the existing root `head.php`, `robots.txt` and older sitemap URLs, which belong to the original site. Relative menu/asset paths work at the existing directory depths, including a subdirectory deployment.

## 8. Performance and accessibility

- No frontend framework, external font request, tracker or autoplay video on new pages.
- Tiny vector cover; the larger PNG is social metadata only, not a page download dependency.
- Existing locally hosted fonts and shared CSS; no duplicate homepage JS on new pages.
- Article text and FAQ answers remain in HTML; controls are progressive enhancement.
- Native FAQ disclosures; menu Escape, focus containment/restore, inert background; visible focus and skip link.
- Reduced-motion handling, meaningful image alternatives, polite status messages and optional locally saved reading size.
- Fluid layout tested at 320, 360, **440, 560, 678, 912, 1200, 1300, 1400, 1500, 1600**, and 1920 pixels.

No claim of PageSpeed/Lighthouse 100 is made. Production compression, caching, CDN, latency and field metrics were not measured. Existing `.htaccess` disables caching; this module does not change that setting. Read TEST-RESULTS.md for exactly what passed and what still needs checking.

## 9. Email and Privacy changes

The shared footer uses the existing `process_contact.php`, with a same-origin POST, browser email validation, loading/success/error feedback and a timeout. It does not add an email database, subscription automation or credentials. Tests use mocked replies; production delivery still depends on the original PHPMailer/server mail setup. No real emails were sent during testing.

Privacy text was revised to match visible implementation: email-only form notifications, direct PDF link rather than invented hashed-IP download analytics, local reading-size preference, existing case-study storage and manual email opt-out rather than a nonexistent unsubscribe endpoint. The owner must review provider details and actual obligations before publication. It is not legal advice or a compliance certification.

## 10. Local verification

Use a PHP-enabled server for the full project:

```sh
php -S 0.0.0.0:8000 -t .
php -l index.php
php -l head.php
php -l footer.php
node --check assets/js/site-shell.js
node --check assets/js/journal.js
node --check assets/js/main.v7.js
python3 tools/build_public_pages.py --check
```

Browser test requires development-only `playwright-core`, `@axe-core/playwright` and an installed Chromium. Install test tools in a separate directory, not production:

```sh
npm install --prefix /path/to/test-tools playwright-core @axe-core/playwright
NODE_PATH=/path/to/test-tools/node_modules \
CHROME_PATH=/path/to/chromium \
BASE_URL=http://127.0.0.1:8000 \
TEST_REPORT=/path/to/browser-results.json \
node tests/public-pages.browser.cjs
```

The automated suite mocks newsletter responses and must not be confused with real email-delivery verification. Manual keyboard, zoom, screen-reader and production-browser testing are still recommended.
