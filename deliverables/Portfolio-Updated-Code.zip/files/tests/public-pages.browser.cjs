/* M001 browser regression tests. See module README for test-only dependencies.
   BASE_URL defaults to local PHP server. CHROME_PATH can select a local Chromium.
   Tests stub newsletter responses; they never submit real email. */
const {chromium} = require('playwright-core');
const AxeBuilder = require('@axe-core/playwright').default;
const assert = require('node:assert/strict');
const fs = require('node:fs');
const base = process.env.BASE_URL || 'http://127.0.0.1:8000';
(async () => {
  const browser = await chromium.launch({executablePath:process.env.CHROME_PATH || undefined,headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
  const context = await browser.newContext();
  const page = await context.newPage();
  const errors = [], badResponses = [];
  page.on('pageerror', error => errors.push(error.message));
  page.on('response', response => {if(response.status()>=400)badResponses.push([response.status(),response.url()]);});
  const paths = ['/blog/','/blog/performance-first-php-websites/','/res/faq.html','/res/privacy.html'];
  const widths = [320,360,440,560,678,912,1200,1300,1400,1500,1600,1920];
  const report = {viewports:[],accessibility:[],checks:[],pageErrors:errors,badResponses};
  for (const path of paths) {
    for (const width of widths) {
      await page.setViewportSize({width,height:900});
      assert.equal((await page.goto(base+path)).status(),200);
      await page.evaluate(()=>document.fonts.ready);
      const layout = await page.evaluate(()=>({width:innerWidth,scrollWidth:document.documentElement.scrollWidth,body:document.body.scrollWidth}));
      assert(layout.scrollWidth<=width+1 && layout.body<=width+1,`Horizontal page overflow at ${path}, ${width}: ${JSON.stringify(layout)}`);
      assert.equal(await page.locator('main').count(),1);assert.equal(await page.locator('h1').count(),1);
      assert(await page.locator('link[rel=canonical]').getAttribute('href'));
      const json = await page.locator('script[type="application/ld+json"]').textContent();assert(JSON.parse(json)['@graph'].length>=4);
      report.viewports.push({path,width,overflow:false});
    }
    for (const width of [440,1400]) {
      await page.setViewportSize({width,height:900});await page.goto(base+path);
      const result=await new AxeBuilder({page}).withTags(['wcag2a','wcag2aa','wcag21aa','best-practice']).analyze();
      report.accessibility.push({path,width,violations:result.violations.map(v=>({id:v.id,impact:v.impact,description:v.description,nodes:v.nodes.map(n=>({target:n.target,summary:n.failureSummary}))}))});
    }
  }
  fs.writeFileSync(process.env.TEST_REPORT || 'public-pages-test-results.json',JSON.stringify(report,null,2));
  // Mobile navigation, keyboard escape, focus trapping and restoration.
  await page.setViewportSize({width:440,height:900});await page.goto(base+'/blog/');
  await page.locator('#menu-btn').click();assert.equal(await page.locator('#mobile-panel').getAttribute('aria-hidden'),'false');
  assert(await page.locator('main').evaluate(el=>el.inert));
  await page.locator('#mobile-panel a').last().focus();await page.keyboard.press('Tab');
  assert(await page.locator('#mobile-panel a').first().evaluate(el=>el===document.activeElement));
  await page.keyboard.press('Escape');assert.equal(await page.locator('#mobile-panel').getAttribute('aria-hidden'),'true');
  assert(await page.locator('#menu-btn').evaluate(el=>el===document.activeElement));
  assert(!(await page.locator('main').evaluate(el=>el.inert)));
  await page.locator('#menu-btn').click();await page.setViewportSize({width:1300,height:900});await page.waitForFunction(()=>document.querySelector('#mobile-panel').getAttribute('aria-hidden')==='true');
  assert.equal(await page.locator('#mobile-panel').getAttribute('aria-hidden'),'true');report.checks.push('Menu open/close, focus trap, Escape, inert restoration, desktop resize');
  // Search, topic, empty state, clear and URL persistence.
  await page.locator('#blog-search').fill('no-matching-article');await page.waitForFunction(()=>!document.querySelector('#blog-empty').hidden);
  assert.equal(await page.locator('[data-article]:visible').count(),0);
  await page.locator('[data-clear-blog]').click();assert.equal(await page.locator('[data-article]:visible').count(),1);
  await page.locator('[data-topic="Accessibility"]').click();assert.equal(await page.locator('[data-article]:visible').count(),1);
  await page.reload();assert.equal(await page.locator('[data-topic="Accessibility"]').getAttribute('aria-pressed'),'true');
  report.checks.push('Blog search, empty/clear state, topic filtering and URL reload');
  // FAQ natural disclosures and search.
  await page.goto(base+'/res/faq.html');assert.equal(await page.locator('.faq-item').count(),32);
  await page.locator('.faq-item').nth(1).locator('summary').click();assert(await page.locator('.faq-item').nth(1).evaluate(el=>el.open));
  await page.locator('#faq-search').fill('not-a-question-anywhere');assert.equal(await page.locator('.faq-item:visible').count(),0);
  await page.locator('[data-clear-faq]').click();assert.equal(await page.locator('.faq-item:visible').count(),32);report.checks.push('32 FAQ disclosures, search and clear');
  // Article optional controls and persisted preference.
  await page.goto(base+paths[1]);const before=await page.locator('[data-reading-body] p').first().evaluate(el=>getComputedStyle(el).fontSize);
  await page.locator('[data-text-size=increase]').click();const after=await page.locator('[data-reading-body] p').first().evaluate(el=>getComputedStyle(el).fontSize);assert(parseFloat(after)>parseFloat(before));
  await page.reload();assert.equal(await page.evaluate(()=>localStorage.getItem('portfolio-reading-size')),'1');
  await page.locator('[data-copy-link]').click();await page.waitForFunction(()=>document.querySelector('#reader-status').textContent.length>0);
  await page.locator('[data-copy-code]').click();await page.waitForFunction(()=>document.querySelector('#reader-status').textContent.length>0);
  await page.locator('#references').scrollIntoViewIfNeeded();assert.notEqual(await page.locator('.entry-progress span').evaluate(el=>getComputedStyle(el).transform),'matrix(0, 0, 0, 1, 0, 0)');
  report.checks.push('Reading text-size/persistence, copy controls, progress');
  // Mock success/error; no real contact/subscription messages are sent.
  await page.route('**/process_contact.php',route=>route.fulfill({status:200,contentType:'application/json',body:'{"status":"success"}'}));
  await page.locator('#subscribe-form input[type=email]').fill('test@example.com');await page.locator('#subscribe-form button').click();await page.waitForFunction(()=>document.querySelector('#subscribe-status').textContent.includes('Request sent'));
  await page.unroute('**/process_contact.php');await page.route('**/process_contact.php',route=>route.fulfill({status:200,contentType:'application/json',body:'{"status":"error"}'}));
  await page.locator('#subscribe-form input[type=email]').fill('test@example.com');await page.locator('#subscribe-form button').click();await page.waitForFunction(()=>document.querySelector('#subscribe-status').textContent.includes('could not be confirmed'));report.checks.push('Newsletter mock success/error, no actual email sent');
  await page.unroute('**/process_contact.php');
  // Homepage header works immediately and after delayed legacy bundle loads.
  await page.setViewportSize({width:440,height:900});await page.goto(base+'/');await page.locator('#menu-btn').click();assert.equal(await page.locator('#mobile-panel').getAttribute('aria-hidden'),'false');await page.keyboard.press('Escape');
  await page.waitForFunction(()=>typeof window.renderProjects==='function');await page.locator('#menu-btn').click();assert.equal(await page.locator('#mobile-panel').getAttribute('aria-hidden'),'false');await page.keyboard.press('Escape');
  assert.equal(await page.locator('#projects-grid .proj-card').count(),15);await page.locator('#view-all-btn').click();assert(!(await page.locator('#projects-grid-more').evaluate(el=>el.classList.contains('hidden'))));report.checks.push('Homepage immediate/legacy menu compatibility, 15 project cards and View All');
  // Static/no-JS and blocked storage do not hide content.
  const nojs=await browser.newContext({javaScriptEnabled:false,viewport:{width:440,height:900}});const plain=await nojs.newPage();
  for(const path of paths){await plain.goto(base+path);assert.equal(await plain.locator('main').count(),1);assert(await plain.locator('main').innerText());}
  await plain.goto(base+'/res/faq.html');await plain.locator('.faq-item').nth(2).locator('summary').click();assert(await plain.locator('.faq-item').nth(2).evaluate(el=>el.open));report.checks.push('All four pages readable without JS; native FAQ still opens');await nojs.close();
  const blocked=await browser.newContext();await blocked.addInitScript(()=>{Object.defineProperty(window,'localStorage',{get(){throw new Error('storage blocked');}});});const bp=await blocked.newPage();await bp.goto(base+paths[1]);await bp.locator('[data-text-size=increase]').click();await blocked.close();report.checks.push('Reading controls tolerate blocked browser storage');
  fs.writeFileSync(process.env.TEST_REPORT || 'public-pages-test-results.json',JSON.stringify(report,null,2));
  console.log(JSON.stringify({viewportChecks:report.viewports.length,axeScans:report.accessibility.length,axeViolations:report.accessibility.reduce((n,x)=>n+x.violations.length,0),checks:report.checks,pageErrors:errors,badResponses},null,2));
  await browser.close();
  if(errors.length || badResponses.length || report.accessibility.some(x=>x.violations.length))process.exitCode=1;
})().catch(error=>{console.error(error);process.exit(1);});
